# GLP-1 Longevity Swap Decision Memo

## Decision

**Recommendation: do not trigger renegotiation of the longevity swap on the supplied 1.5% cohort-survival threshold.**

The GLP-1-adjusted scenario improves projected survival in every evaluated cohort, but none of the cohort-level survival deviations exceeds the 1.5% materiality threshold. The largest absolute deviation is **0.266%**, for the cohort aged **64 in 2024**, which is materially below the contractual trigger.

## Modelling approach

The corrected historical mortality file contains a complete combined-sex (`B`) grid for ages 50-90 and calendar years 2000-2022. The coverage audit therefore has **943 observed rows out of 943 expected rows, with no age/year gaps**.

The baseline model uses the Lee-Carter specification:

`log(m_x,t) = alpha_x + beta_x * kappa_t`

The historical mortality surface is centered by age and fitted with a first-component SVD. The usual Lee-Carter identification constraints are then applied so that `sum(beta_x) = 1` and `mean(kappa_t) = 0`.

A linear drift is fitted to historical `kappa_t` and projected over 2024-2050. The GLP-1 scenario applies the supplied cause-deleted obesity mortality adjustment with the corrected prevalence path, which rises from 2% in 2024 to 20% in 2034 and remains at 20% thereafter. The supplied fictional efficacy assumption is 15% of the obesity-attributable mortality fraction for treated individuals. The adjusted future mortality surface is then projected back onto the baseline `beta_x` vector to obtain an adjusted `kappa_t` path.

## Parameter changes

The adjusted-model implementation keeps `alpha_x` and `beta_x` fixed to the baseline age pattern, so their changes are **0 by construction**. The scenario effect is expressed through the future `kappa_t` path and the projected mortality surface.

The fitted historical `kappa_t` drift is approximately **-0.615000 per year**. For 2024, projected baseline `kappa_t` is **-7.995001** and adjusted `kappa_t` is **-8.012224**, a difference of **-0.017224**. By 2050, projected baseline `kappa_t` is **-23.985002** and adjusted `kappa_t` is **-24.157575**, a difference of **-0.172573**.

Across the full age/year projection surface, the GLP-1 adjustment reduces central mortality rates by approximately **0.030% to 0.540%**, depending on age and prevalence year.

## Cohort deviation findings

Cohorts are indexed by attained age in 2024 and followed diagonally through the projected surface until 2050 or age 90, whichever comes first. Under a constant-force approximation, cumulative survival over each observed cohort path is calculated as:

`S = exp(-sum(m_x,t))`

The report compares the baseline and adjusted survival probabilities and calculates:

`deviation_pct = 100 * (adjusted_survival / baseline_survival - 1)`

A cohort is flagged when `abs(deviation_pct) > 1.5`.

**Result: 0 of 41 cohorts are flagged.** The maximum deviation is **0.266%**, well below the 1.5% trigger.

The improvement is directionally consistent with lower mortality, but it is not large enough under these assumptions to satisfy the stated renegotiation threshold.

## Limitations

This conclusion is conditional on the supplied scenario inputs and modelling structure. The corrected task data are fictional scenario inputs rather than observed plan-specific GLP-1 claims experience. The prevalence path, obesity-attributable fractions, efficacy assumption, linear `kappa_t` drift, and constant-force conversion from central mortality rates to cohort survival all affect the result.

The model also holds the baseline `alpha_x` and `beta_x` age pattern fixed in the adjusted scenario and represents the GLP-1 effect through the mortality surface and refitted future `kappa_t`. A materially different uptake path, treatment effect, persistence assumption, or covered-population risk mix could change the conclusion.

## Recommendation

On the supplied evidence, the GLP-1 mortality improvement is **not material enough to warrant renegotiating the longevity swap** under a 1.5% cohort-survival deviation clause. The scenario should remain a monitored sensitivity in the longevity basis, but the current modelled effect does not reach the contractual materiality threshold.
